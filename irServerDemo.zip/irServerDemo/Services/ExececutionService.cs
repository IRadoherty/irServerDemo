﻿using System.Net;
using System.Net.Http.Headers;
using System.Text;
using irServerDemo.Models.Requests;
using irServerDemo.Models.Responses;
using Newtonsoft.Json;

namespace irServerDemo.Services;

public interface IExecutionService
{
    Task<ExecutionResponse> ApplyRules(ApplyRules request, string ExecutionServiceUrl);
    Task<ExecutionResponse> ExecuteRuleSet(ExecuteRuleSet request, string ExecutionServiceUrl);
}


public class ExecutionService : IExecutionService
{
    public async Task<ExecutionResponse> ApplyRules(ApplyRules request, string ExecutionServiceUrl)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(ExecutionServiceUrl);
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        var requestJson = JsonConvert.SerializeObject(request);
        var content = new StringContent(requestJson, Encoding.UTF8, "application/json");
        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        var response = await client.PostAsync(ExecutionServiceUrl, content);
        var responseString = await response.Content.ReadAsStringAsync();

        return JsonConvert.DeserializeObject<ExecutionResponse>(responseString) ??
               throw new InvalidOperationException();
    }
    public async Task<ExecutionResponse> ExecuteRuleSet(ExecuteRuleSet request, string ExecutionServiceUrl)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(ExecutionServiceUrl);
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        var requestJson = JsonConvert.SerializeObject(request);
        var first = requestJson.FirstOrDefault();
        var content = new StringContent(requestJson, Encoding.UTF8, "application/json");

        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        var response = await client.PostAsync(ExecutionServiceUrl, content);
        var responseString = await response.Content.ReadAsStringAsync();

        return JsonConvert.DeserializeObject<ExecutionResponse>(responseString) ??
               throw new InvalidOperationException();
    }
}