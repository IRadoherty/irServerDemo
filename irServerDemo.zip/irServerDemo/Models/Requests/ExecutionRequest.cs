﻿namespace irServerDemo.Models.Requests;
public class ExecuteRuleSet : ApplyRules
{
    public string? RuleSetName { get; set; }
}
public class ApplyRules
{
    public RuleApp? RuleApp { get; set; }
    //public RuleEngineServiceOptions? RuleEngineServiceOptions { get; set; }
    //public RuleEngineServiceOutputTypes? RuleEngineServiceOutputTypes { get; set; }
    public string? EntityState { get; set; }
    public string? EntityName { get; set; }
}

public class Override
{
    public string? Connectionstring { get; set; }
    public string? RestOperationBody { get; set; }
    public List<RestOperationHeader> RestOperationHeaders { get; set; }
    public string? RestServiceDomain { get; set; }
    public string? RestServicePassword { get; set; }
    public string? RestServiceRootUrl { get; set; }
    public string? RestServiceUserName { get; set; }
    public string? Name { get; set; }
    public int OverrideType { get; set; }
    public string? PropertyName { get; set; }
    public string? Value { get; set; }
}

public class RepositoryRuleAppRevisionSpec
{
    public string? Label { get; set; }
    public long Revision { get; set; }
    public string? RuleApplicationName { get; set; }
}

public class RestOperationHeader
{
    public string? HeaderName { get; set; }
    public string? HeaderValue { get; set; }
}


public class RuleApp
{
    //public long CacheTimeout { get; set; }
    public RepositoryRuleAppRevisionSpec? RepositoryRuleAppRevisionSpec { get; set; }
}

public class RuleEngineServiceOptions
{
    public List<Override>? Overrides { get; set; }
    public RuleSessionOverrides? RuleSessionOverrides { get; set; }
}

public class RuleEngineServiceOutputTypes
{
    public bool ActiveNotifications { get; set; }
    public bool ActiveValidations { get; set; }
    public bool EntityState { get; set; }
    public bool Overrides { get; set; }
    public bool RuleExecutionLog { get; set; }
    public bool Parameters { get; set; }
}

public class RuleSessionOverrides
{
    public string? ExecutionTimeout { get; set; }
    public long MaxCycleCount { get; set; }
}

