﻿using irServerDemo.Models.Requests;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using irServerDemo.Models.Responses;
using irServerDemo.Services;


namespace irServerDemo.Controllers;

[EnableCors("EnableCORS")]
[ApiController]
public class irServerController : ControllerBase
{
    private readonly IExecutionService _irServerService;

    public irServerController(IExecutionService irServerService)
    {
        _irServerService = irServerService;
    }

    /// <summary>
    /// Post an Apply Rules request. irServer endpoint example: https://irserver.azurewebsites.net/HttpService.svc/ApplyRules
    /// </summary>
    /// <param name="ExecutionServiceUrl">The URL of the execution service</param>
    /// <param name="request">The rule request body for the apply rules request</param>
    /// <returns name="request">The rule request body for the apply rules request</returns>
    /// <remarks>
    /// Multiplication ApplyRules Post Request:
    /// 
    ///     {
    ///        "RuleApp":{
    ///            "RepositoryRuleAppRevisionSpec":{
    ///                "RuleApplicationName": "MultiplicationApp"
    ///            }
    ///        },
    ///        "EntityName": "MultiplicationProblem",
    ///        "EntityState": "{'FactorA': 12.4, 'FactorB': 3.1}",
    ///        "Label": LIVE
    ///     }
    /// </remarks>
    /// <returns>A newly created employee</returns>
    /// <response code="200">Returns a successful execution response</response>
    /// <response code="500">Some error has occurred during rule execution</response>
    [HttpPost(nameof(ApplyRules))]
    [Route("ApplyRules")]
    [ProducesResponseType(200)]
    [ProducesResponseType(500)]
    [Produces("application/json")]
    [Consumes("application/json")]
    public async Task<IActionResult> ApplyRules(
        [FromBody] ApplyRules request, string executionServiceUrl)
    {
        var thisste = "";
        var response = await _irServerService.ApplyRules(request, executionServiceUrl);
            return Ok(response);
    }

    /// <summary>
    /// Post an ExecuteRuleSet Request ExecuteRuleSet endpoint example: https://irserver.azurewebsites.net/HttpService.svc/ExecuteRuleSet
    /// </summary>
    /// <param name="ExecutionServiceUrl">The URL of the execution service</param>
    /// <param name="request">The rule request body for the execute ruleset request</param>
    /// <returns response="response">The rule request body for the apply rules response</returns>
    /// <remarks>
    /// Multiplication ExecuteRuleSet Post Request:
    /// 
    ///     {
    ///        "RuleApp":{
    ///            "RepositoryRuleAppRevisionSpec":{
    ///                "RuleApplicationName": "MultiplicationApp",
    ///                 "Label": LIVE
    ///            }
    ///        },
    ///        "EntityName": "MultiplicationProblem",
    ///        "EntityState": "{'FactorA': 12.4, 'FactorB': 3.1}"
    ///        "RuleSet": "MultiplyAfterRounding"
    ///     }
    /// </remarks>
    /// <returns>A newly created employee</returns>
    /// <response code="200">Returns a successful execution response</response>
    /// <response code="500">Some error has occurred during rule execution</response>
    [HttpPost(nameof(ExecuteRuleSet))]
    [Route("ExecuteRuleSet")]
    [ProducesResponseType(200)]
    [ProducesResponseType(500)]
    [Produces("application/json")]
    [Consumes("application/json")]
    public async Task<IActionResult> ExecuteRuleSet(
        [FromBody] ExecuteRuleSet request, string executionServiceUrl)
    {
        var response = await _irServerService.ExecuteRuleSet(request, executionServiceUrl);
        return Ok(response);
    }
}
